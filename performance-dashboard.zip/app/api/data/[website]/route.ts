import { type NextRequest, NextResponse } from "next/server"
import Database from "better-sqlite3"
import path from "path"

export async function GET(request: NextRequest, { params }: { params: { website: string } }) {
  try {
    // Connect to your existing SQLite database
    // Update this path to match your database location
    const dbPath = path.join(process.cwd(), "sitemonitor.db")
    const db = new Database(dbPath)

    const website = decodeURIComponent(params.website)

    // Query your existing measurements table
    const query = `
      SELECT website, timestamp, ttfb, loading_delay 
      FROM measurements 
      WHERE website = ? 
      ORDER BY timestamp DESC 
      LIMIT 1000
    `

    const measurements = db.prepare(query).all(website)

    // Close database connection
    db.close()

    return NextResponse.json(measurements)
  } catch (error) {
    console.error("Database error:", error)
    return NextResponse.json({ error: "Failed to fetch data" }, { status: 500 })
  }
}
