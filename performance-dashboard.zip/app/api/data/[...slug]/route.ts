import { type NextRequest, NextResponse } from "next/server"
import sqlite3 from "sqlite3"

const DB_FILE = "sitemonitor.db"

// Helper function to run database queries
async function runQuery(query: string, params: any[] = []): Promise<any[]> {
  return new Promise((resolve, reject) => {
    const db = new sqlite3.Database(DB_FILE)

    db.all(query, params, (err, rows) => {
      if (err) {
        reject(err)
      } else {
        resolve(rows || [])
      }
    })

    db.close()
  })
}

export async function GET(request: NextRequest, { params }: { params: { slug: string[] } }) {
  try {
    const website = decodeURIComponent(params.slug.join("/"))
    const { searchParams } = new URL(request.url)
    const timeframe = searchParams.get("timeframe") || "daily"

    let query = ""
    const queryParams: any[] = [website]

    const now = new Date()

    if (timeframe === "daily") {
      // Get today's data
      const today = now.toISOString().split("T")[0]
      query = `
        SELECT timestamp, ttfb, loading_delay
        FROM measurements
        WHERE website = ? AND DATE(timestamp) = ?
        ORDER BY timestamp ASC
      `
      queryParams.push(today)
    } else if (timeframe === "weekly") {
      // Get this week's data
      const startOfWeek = new Date(now)
      startOfWeek.setDate(now.getDate() - now.getDay())
      startOfWeek.setHours(0, 0, 0, 0)

      const endOfWeek = new Date(startOfWeek)
      endOfWeek.setDate(startOfWeek.getDate() + 6)
      endOfWeek.setHours(23, 59, 59, 999)

      query = `
        SELECT timestamp, ttfb, loading_delay
        FROM measurements
        WHERE website = ? AND timestamp BETWEEN ? AND ?
        ORDER BY timestamp ASC
      `
      queryParams.push(startOfWeek.toISOString(), endOfWeek.toISOString())
    } else if (timeframe === "monthly") {
      // Get this month's data
      const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1)
      const endOfMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59, 999)

      query = `
        SELECT timestamp, ttfb, loading_delay
        FROM measurements
        WHERE website = ? AND timestamp BETWEEN ? AND ?
        ORDER BY timestamp ASC
      `
      queryParams.push(startOfMonth.toISOString(), endOfMonth.toISOString())
    }

    const rows = await runQuery(query, queryParams)

    return NextResponse.json(
      rows.map((row) => ({
        timestamp: row.timestamp,
        ttfb: row.ttfb,
        loading_delay: row.loading_delay,
      })),
    )
  } catch (error) {
    console.error("Database error:", error)
    return NextResponse.json({ error: "Failed to fetch data" }, { status: 500 })
  }
}
